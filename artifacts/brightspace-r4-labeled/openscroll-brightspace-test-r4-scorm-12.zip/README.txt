OpenScroll SCORM 1.2
Upload this complete ZIP to an LMS as one SCO. Do not import it as an editable project.
Tracks aggregate score, completion, bookmark, session time and resume data. No question-level interactions report.
SCORM 1.2 has a 4096-character resume limit; SCORM 2004 supports 64000. Oversized saves show an error and retain progress in memory. Use Save LMS progress before exiting.
Review/browse launches are read-only. A changed publication cannot restore an earlier publication checkpoint. LMS policy governs new attempts and retakes.
SCORM 1.2 reports incomplete until all lessons are completed, then passed/failed if assessed, otherwise completed. SCORM 2004 reports completion and success independently.
See LICENSE.txt, NOTICE.txt and THIRD-PARTY-NOTICES.txt. Authored content retains its own rights.
